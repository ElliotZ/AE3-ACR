﻿namespace ElliotZ.Rpr.QtUI.Hotkey
{
    internal class Ingress
    {
    }
}
